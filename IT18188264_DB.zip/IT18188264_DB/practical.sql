-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2020 at 07:55 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `practical`
--

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `patient_id` int(11) NOT NULL,
  `p_nic` varchar(12) NOT NULL,
  `p_fname` varchar(45) NOT NULL,
  `p_lname` varchar(45) NOT NULL,
  `p_dob` date NOT NULL,
  `p_address` varchar(100) NOT NULL,
  `p_phone` varchar(10) NOT NULL,
  `p_email` varchar(45) DEFAULT NULL,
  `p_gender` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`patient_id`, `p_nic`, `p_fname`, `p_lname`, `p_dob`, `p_address`, `p_phone`, `p_email`, `p_gender`) VALUES
(3, '917283765V', 'Supun', 'Fernando', '1991-02-03', 'Jaffna', '0765283716', 'suppa123@gmail.com', 'Male'),
(4, '987200799V', 'Shalini', 'Perera', '1998-08-07', 'No 611 Station road Wattala', '0712054107', 'shalinip437@gmail.com', 'Female'),
(5, '658394028V', 'Nimal', 'Gunathilaka', '1965-06-08', 'No 7, Seevali Road, Deniyaya', '0756754345', 'shalinip437@gmail.com', 'Male'),
(7, '943528376V', 'Swetha', 'woods', '2000-03-04', 'Colombo', '0716273958', 'swetha@gmail.com', 'Female'),
(8, '973625367V', 'Menusha', 'Dabare', '1998-02-03', 'NuwaraEliya town', '0763528903', 'menusha123@gmail.com', 'Female');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`patient_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `patient_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
